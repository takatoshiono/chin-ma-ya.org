package MapFan::MobileLinkService;
use strict;
use warnings;
use base qw( Class::Data::Inheritable Class::Accessor::Fast );
use URI;
use Jcode;
use Geo::Coordinates::Converter;

__PACKAGE__->mk_classdata(
    base_uri => URI->new('http://link.mapfan.com/link.cgi')
);

__PACKAGE__->mk_accessors(qw(
    base_uri ref rname zm
));

sub new {
    my $class = shift;
    my $self = $class->SUPER::new(@_);
    $self->init(@_);
    $self;
}

sub init {
    my $self = shift;
}

sub mk_latlng_link {
    my ($self, %args) = @_;

    my ($lat, $lng);
    if (exists $args{datum}) {
        my $geo = Geo::Coordinates::Converter->new(
            lat   => $args{lat},
            lng   => $args{lng},
            datum => $args{datum},
        );
        $geo->convert($args{datum} => 'tokyo');
        my $point = $geo->convert(tokyo => 'dms');
        ($lat, $lng) = ($point->lat, $point->lng);
    }
    else {
        ($lat, $lng) = @args{qw/lat lng/};
    }

    my $sn = $args{sn} || '';

    my $uri = $self->base_uri->clone;
    my %query = (
        REF   => url_encode($self->ref),
        RNAME => url_encode(Jcode->new($self->rname)->sjis),
        ZM    => $self->zm,
        MAP   => sprintf('E%sN%s', $lng, $lat),
        SN    => url_encode(Jcode->new($sn)->sjis),
    );
    #$uri->query_form(%query);
    $uri->query(join(q{&}, map("$_=$query{$_}", keys %query)));

    return $uri->as_string;
}

sub url_encode {
    my $str = shift;
    $str =~ s/([^\w ])/'%' . unpack('H2', $1)/eg;
    $str =~ tr/ /+/;
    $str;
}

1;

__END__

Copyright 2007, Takatoshi Ono

=head1 SYNOPSIS

    my $mapfan = MapFan::MobileLinkService->new({
        ref=> 'http://takatoshi.dyndns.org/tinma/moti.cgi',
        rname => 'tinma',
        zm    => 9,
    });

    my $url = $mapfan->mk_latlng_link(
        lat   => $lat,
        lng   => $lng,
        sn    => $spot_name
        datum => $datum, # option. necessary if you set lat,lng as not tokyo-dms format
    );

=cut

