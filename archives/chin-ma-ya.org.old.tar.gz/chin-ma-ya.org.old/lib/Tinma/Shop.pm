package Tinma::Shop;
use strict;
use warnings;
use base qw/ Class::Accessor::Fast /;

__PACKAGE__->mk_accessors(
    qw/ name address extra lat lng /
);

1;

