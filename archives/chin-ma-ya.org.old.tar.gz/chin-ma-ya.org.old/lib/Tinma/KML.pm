package Tinma::KML;
use strict;
use warnings;
use Template;
use Carp;

sub new {
    my ($class, %args) = @_;
    my $self = bless {
        dir      => './',
        file     => 'tinma.kml',
        tmpl_dir => '/home/takatoshi/app/tinma/template',
        %args,
    }, $class;
    $self;
}

sub generate {
    my ($self, $shops) = @_;

    my $output_file = File::Spec->catfile(
        $self->{dir}, $self->{file}
    );

    my $tt = Template->new(
        { INCLUDE_PATH => $self->{tmpl_dir} }
    ) or croak $Template::ERROR;

    $tt->process(
        'tinma.kml.tt2',
        { shops => $shops },
        $output_file
    ) or croak $tt->error;

    return $output_file;
}

1;

__END__

