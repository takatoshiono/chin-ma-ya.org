package Moti;
use strict;
use warnings;
use base qw(Exporter);
our @EXPORT_OK = qw(
    search
);

use Data::Page;
use Readonly;

# ページあたりの表示数
Readonly my $entries_per_page => 10;

# 1度あたりの距離
# http://ja.wikipedia.org/wiki/%E7%B7%AF%E5%BA%A6
# http://ja.wikipedia.org/wiki/%E7%B5%8C%E5%BA%A6
# 緯度１秒の長さ(緯度35度上) 約30.8m
# 経度１秒の長さ(緯度35度上) 約25m
Readonly my $dx_unit => 30.8 * 3600;
Readonly my $dy_unit => 25.0 * 3600;

sub search {
    my ($dbh, $lat, $lng, $current_page) = @_;

    ($lat, $lng) = ($lat + 0, $lng + 0);
    return [] unless $lat and $lng;

    my $offset = $current_page == 1 ? 0 : $entries_per_page * ($current_page - 1) + 1;

    my ($total_entries) = $dbh->selectrow_array(
        q{SELECT COUNT(*) FROM shops}
    );

    my $page = Data::Page->new();
    $page->total_entries($total_entries);
    $page->entries_per_page($entries_per_page);
    $page->current_page($current_page);

    my $sql = sprintf(q{
        SELECT
            *,
            FLOOR(SQRT(dx*dx + dy*dy) * 1000 + 0.5) / 1000 AS distance
        FROM (
            SELECT
                *,
                FLOOR(((longitude - ?) * ?) + 0.5) / 1000 AS dx,
                FLOOR(((latitude  - ?) * ?) + 0.5) / 1000 AS dy
            FROM
                shops
            WHERE
                deleted_at IS NULL
        ) AS shops
        ORDER BY
            distance ASC
        LIMIT
            %d, %d
    }, $offset, $entries_per_page);

    my $shops = $dbh->selectall_arrayref(
        $sql,
        { Slice => {} },
        $lng, $dx_unit, $lat, $dy_unit
    );

    return wantarray ? ($shops, $page) : $shops;
}

1;

