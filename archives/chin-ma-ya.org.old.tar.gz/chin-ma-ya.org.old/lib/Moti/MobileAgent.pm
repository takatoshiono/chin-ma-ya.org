package Moti::MobileAgent;
use strict;
use warnings;
use HTTP::MobileAgent;
use UNIVERSAL::require;
use Geocoder;

sub new {
    my ($class, %args) = @_;
    my $agent = HTTP::MobileAgent->new;
    my $module = $class . '::' . $agent->carrier_longname;
    $module->require or die $@;
    my $self = bless {
        agent => $agent,
        %args,
    }, $module;
    $self->init;
    $self;
}

sub init  {
    my $self = shift;
    my $params = $self->{params};
    my ($lnd, $lat, $lng) = @$params{qw/lnd lat lon/};
    if ($lnd) {
        $self->{geo} = Geocoder->new();
        ($self->{lat}, $self->{lng})
            = $self->{geo}->get_lat_lng($lnd);
        $self->{unit} = 'degree';
        $self->{datum} = 'wgs84';
    }
    elsif ($lat and $lng) {
        $self->{lat} = $lat;
        $self->{lng} = $lng;
        $self->{unit}  = $params->{unit};
        $self->{datum} = $params->{datum};
    }
}

sub lat   { shift->{lat} }
sub lng   { shift->{lng} }
sub datum { die 'This is a abstract method.' }
sub unit  { die 'This is a abstract method.' }
sub agent { shift->{agent} }

1;

