package Moti::MobileAgent::Vodafone;
use strict;
use warnings;
use base 'Moti::MobileAgent';

# http://developers.softbankmobile.co.jp/dp/tool_dl/web/tech.php
# (HTML編)

sub init {
    my $self = shift;
    $self->SUPER::init();
    if ($self->{params}{pos} =~ /^N(.+)\.E(.+)$/) {
        $self->{lat} = $1;
        $self->{lng} = $2;
    }
}

sub datum { shift->{geo} || 'wgs84' }
sub unit { return 'dms' }

1;

