package Moti::MobileAgent::EZweb;
use strict;
use warnings;
use base 'Moti::MobileAgent';

# http://www.au.kddi.com/ezfactory/tec/spec/eznavi.html

sub datum { shift->{datum} || 'wgs84' }
#sub datum { shift->{params}{datum} }

sub unit  {
    my $self = shift;
    my $unit = $self->{unit} || $self->{params}{unit};
    if ($unit =~ /^\d+$/) {
        if ($unit == 0) {
            return 'dms';
        }
        else {
            return 'degree'; # maybe..
        }
    }
    else {
        return $unit;
    }
}

1;

