package Moti::MobileAgent::AirH;
use strict;
use warnings;
use base 'Moti::MobileAgent';

sub init {
    my $self = shift;
    $self->SUPER::init();
    if ($self->{params}{pos} =~ /^N(.+)E(.+)$/) {
        $self->{lat} = $1;
        $self->{lng} = $2;
        $self->{datum} = 'tokyo';
        $self->{unit} = 'dms';
    }
}

sub datum { shift->{datum} || 'tokyo' }
sub unit  { shift->{unit} || 'dms' }

1;

