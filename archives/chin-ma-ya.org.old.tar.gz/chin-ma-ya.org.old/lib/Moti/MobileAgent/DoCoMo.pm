package Moti::MobileAgent::DoCoMo;
use strict;
use warnings;
use base 'Moti::MobileAgent';

sub datum {
    my $self = shift;
    $self->{datum} || $self->{params}{geo} || 'wgs84';
}
sub unit {
    my $self = shift;
    $self->{unit} || $self->{params}{unit} || 'dms';
}

1;

