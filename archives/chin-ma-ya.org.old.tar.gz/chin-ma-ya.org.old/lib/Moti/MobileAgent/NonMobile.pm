package Moti::MobileAgent::NonMobile;
use strict;
use warnings;
use base 'Moti::MobileAgent';

sub init {
    my $self = shift;
    $self->SUPER::init();
}

sub datum {
    my $self = shift;
    $self->{datum} || $self->{params}{datum} || 'wgs84';
}
sub unit  {
    my $self = shift;
    $self->{unit} || $self->{params}{unit} || 'degree';
}

1;

