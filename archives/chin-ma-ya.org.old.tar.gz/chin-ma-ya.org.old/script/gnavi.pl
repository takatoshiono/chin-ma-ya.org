#!/usr/bin/perl
use strict;
use warnings;
use WebService::Gnavi;
use DBI;
use YAML;

MAIN:
{
    my $dbh = DBI->connect('dbi:mysql:tinma', 'root', undef,
        { AutoCommit => 1, RaiseError => 1 }
    );
    do_work($dbh);
    $dbh->disconnect();
}

sub do_work {
    my $dbh = shift;

    my $shops = fetch_shops($dbh);

    my $gnavi = WebService::Gnavi->new(
        access_key => '5bab0168e3782e0647bd9cacc703109f',
    );

    SHOP:
    foreach my $shop (@$shops) {
        my $result;
        eval {
            $result = $gnavi->search({
                name => sprintf('陳麻家 %s', $shop->{name}),
            });
        };
        if ($@) {
            print STDERR "no shop found($shop->{name}): $@\n";
            next SHOP;
        }

        my @tinmas = $result->list();
        if (@tinmas) {
            save_gnavi($dbh, $shop->{id}, $tinmas[0]);
        }
    }
}

sub fetch_shops {
    my $dbh = shift;
    my $shops = $dbh->selectall_arrayref(
        'SELECT * FROM shops WHERE deleted_at IS NULL ORDER BY id',
        { Slice => {} },
    );
    return $shops;
}

sub save_gnavi {
    my ($dbh, $shop_id, $shop) = @_;

    print "save: $shop->{name}\n";

    my ($is_exists) = $dbh->selectrow_array(q{
        SELECT 1 FROM gnavi_shops
        WHERE gnavi_shop_id = ? AND deleted_at IS NULL
    }, undef, $shop->{id});

    if ($is_exists) {
        update_gnavi_shop($dbh, $shop);
    }
    else {
        insert_gnavi_shop($dbh, $shop_id, $shop);
    }
}

sub update_gnavi_shop {
    my ($dbh, $shop) = @_;

    my $sql = q{
        UPDATE gnavi_shops
        SET
            name = ?,
            name_kana = ?,
            url = ?,
            url_mobile = ?,
            shop_image1 = ?,
            shop_image2 = ?,
            qrcode = ?,
            address = ?,
            tel = ?,
            fax = ?,
            opentime = ?,
            holiday = ?,
            line = ?,
            station = ?,
            station_exit = ?,
            walk = ?,
            note = ?,
            pr_short = ?,
            pr_long = ?,
            budget = ?,
            equipment = ?
        WHERE
            gnavi_shop_id = ? AND updated_at < ?
    };

    my @bind_values = (
        $shop->{name},
        $shop->{name_kana},
        $shop->{url},
        $shop->{url_mobile},
        $shop->{image_url}{shop_image1},
        $shop->{image_url}{shop_image2},
        $shop->{image_url}{qrcode},
        $shop->{address},
        $shop->{tel},
        $shop->{fax},
        $shop->{opentime},
        $shop->{holiday},
        $shop->{access}{line},
        u2e($shop->{access}{station}),
        $shop->{access}{station_exit},
        $shop->{access}{walk},
        $shop->{access}{note},
        $shop->{pr}{pr_short},
        $shop->{pr}{pr_long},
        $shop->{budget},
        $shop->{equipment},
        $shop->{id},
        $shop->{update_date},
    );

    $dbh->do($sql, undef, @bind_values);
}

sub insert_gnavi_shop {
    my ($dbh, $shop_id, $shop) = @_;

    my $sql = q{
        INSERT INTO gnavi_shops(
            shop_id,
            gnavi_shop_id,
            name,
            name_kana,
            url,
            url_mobile,
            shop_image1,
            shop_image2,
            qrcode,
            address,
            tel,
            fax,
            opentime,
            holiday,
            line,
            station,
            station_exit,
            walk,
            note,
            pr_short,
            pr_long,
            budget,
            equipment,
            created_at
        ) VALUES (
            ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,
            ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,
            ?, ?, ?, now()
        )
    };

    my @bind_values = (
        $shop_id,
        $shop->{id},
        $shop->{name},
        $shop->{name_kana},
        $shop->{url},
        $shop->{url_mobile},
        $shop->{image_url}{shop_image1},
        $shop->{image_url}{shop_image2},
        $shop->{image_url}{qrcode},
        $shop->{address},
        $shop->{tel},
        $shop->{fax},
        $shop->{opentime},
        $shop->{holiday},
        $shop->{access}{line},
        u2e($shop->{access}{station}),
        $shop->{access}{station_exit},
        $shop->{access}{walk},
        $shop->{access}{note},
        $shop->{pr}{pr_short},
        $shop->{pr}{pr_long},
        $shop->{budget},
        $shop->{equipment}
    );

    $dbh->do($sql, undef, @bind_values);
}

# undefined to empty string
sub u2e {
    my $str = shift;
    if (defined $str) {
        return $str;
    }
    else {
        return '';
    }
}

__END__

