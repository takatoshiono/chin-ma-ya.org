#!/usr/bin/perl
# うまくGeocodingできない住所用だが、コレでもうまくいかない住所がある
use strict;
use warnings;
use DBI;
use Geocoder;

{
    my $dbh = DBI->connect('dbi:mysql:tinma', 'root', undef,
        { AutoCommit => 1, RaiseError => 1 }
    );
    do_work($dbh);
    $dbh->disconnect;
}

sub do_work {
    my $dbh = shift;
    my @ids = qw/7 15 21 36 39 44 51/;

    foreach my $id (@ids) {
        my $shop = $dbh->selectrow_hashref(
            'SELECT * FROM shops WHERE id = ?',
            undef, $id
        );
        $shop->{address} =~ s/ビル.+$//;
        my ($lat, $lng) = get_lat_lng($shop->{address});
        $dbh->do(
            'UPDATE shops SET latitude = ?, longitude = ? WHERE id = ?',
            undef, $lat, $lng, $id
        );
    }
}

my $geocoder;
sub get_lat_lng {
    my $address = shift;
	$geocoder ||= Geocoder->new;
    my ($lat, $lng) = $geocoder->get_lat_lng($address);
    print "$address: $lat, $lng\n";
    return ($lat, $lng);
}

__END__

