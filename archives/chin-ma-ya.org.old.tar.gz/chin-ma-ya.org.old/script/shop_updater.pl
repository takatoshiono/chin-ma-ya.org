#!/usr/bin/perl
use strict;
use warnings;
use DBI;
use YAML;
use Encode;
use Readonly;

use FindBin;
use lib "$FindBin::Bin/../lib";
use Tinma::Scraper;
use Tinma::KML;
use Net::Twitter;

Readonly my $KML_DIR => '/home/takatoshi/app/tinma/htdocs';

{
    my $dbh = DBI->connect('dbi:mysql:tinma', 'root', undef,
        { AutoCommit => 1, RaiseError => 1 }
    );
    do_work($dbh);
    $dbh->disconnect;
}

sub do_work {
    my $dbh = shift;

    my $areas = fetch_areas($dbh);
    #print Dump $areas;

    my $scraper = Tinma::Scraper->new();
    my $twitter = Net::Twitter->new(username => 'tinma', password => 'tinmanko!1234');

    $dbh->begin_work
        or die $dbh->errstr;

    my $is_updated = 0;
    eval {
        AREA:
        foreach my $area (@$areas) {
            my $is_exists = fetch_shops($dbh, $area->{id});
            #print Dump $is_exists;

            my $shops = eval {
                $scraper->get_shops($area->{initial_words});
            };
            if ($@) {
                next AREA;
            }
            #print Dump $shops;

            ADD_SHOP:
            foreach my $shop (@$shops) {
                my $shop_name = encode('utf-8', $shop->name);
                unless (delete $is_exists->{$shop_name}) {
                    my $shop_id = add_shop($dbh, $area->{id}, $shop);
                    $twitter->update(sprintf('New Open! 陳麻家 %s http://chin-ma-ya.org/shops/%d', $shop_name, $shop_id));
                    $is_updated = 1;
                }
            }

            DELETE_SHOP:
            foreach my $shop (values %$is_exists) {
                delete_shop($dbh, $shop);
                $twitter->update(sprintf('Closed.. 陳麻家 %s', $shop->{name}));
                $is_updated = 1;
            }
        }

        $dbh->commit;
    };
    if ($@) {
        warn "Transaction failed: $@";
        $dbh->rollback;
    }
}

sub fetch_areas {
    my $dbh = shift;
    my $areas = $dbh->selectall_arrayref(
        'SELECT * FROM areas WHERE deleted_at IS NULL ORDER BY id ASC',
        { Slice => {} },
    );
    return $areas;
}

sub fetch_shops {
    my ($dbh, $area_id) = @_;
    my $shops = $dbh->selectall_hashref(
        q{
            SELECT * FROM shops
            WHERE area_id = ? AND deleted_at IS NULL
            ORDER BY id ASC
        },
        'name', undef, $area_id
    );
    return $shops;
}

sub add_shop {
    my ($dbh, $area_id, $shop) = @_;
    print "add ", $shop->name, "\n";

    $dbh->do(
        q{
            INSERT INTO shops(
                area_id, name, address,
                latitude, longitude, extra, created_at
            ) VALUES (
                ?, ?, ?, ?, ?, ?, now()
            )
        },
        undef,
        $area_id, $shop->name, $shop->address,
        $shop->lat, $shop->lng, $shop->extra
    );
    my $shop_id = $dbh->selectrow_arrayref('SELECT LAST_INSERT_ID()')->[0];
    return $shop_id;
}

sub delete_shop {
    my ($dbh, $shop) = @_;
    print "delete ", $shop->{name}, "\n";

    $dbh->do(
        'UPDATE shops SET deleted_at = now() WHERE id = ?',
        undef, $shop->{id}
    );
}

__END__

