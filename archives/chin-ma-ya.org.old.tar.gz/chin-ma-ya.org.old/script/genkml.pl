#!/usr/bin/perl
use strict;
use warnings;
use DBI;
use FindBin;
use lib "$FindBin::Bin/../lib";
use Tinma::KML;

{
    my $dbh = DBI->connect('dbi:mysql:tinma', 'root', undef,
        { AutoCommit => 1, RaiseError => 1 }
    );
    do_work($dbh);
    $dbh->disconnect;
}

sub do_work {
    my $dbh = shift;
    my $shops = fetch_shops($dbh);
    my $kml = Tinma::KML->new();
    $kml->generate($shops);
}

sub fetch_shops {
    my $dbh = shift;
    $dbh->selectall_arrayref(
        'SELECT * FROM shops WHERE deleted_at IS NULL ORDER BY id ASC',
        { Slice => {} }
    );
}

__END__

