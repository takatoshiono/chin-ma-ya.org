#!/usr/bin/perl
use strict;
use warnings;
use DBI;
use YAML;
use Getopt::Long;
use Geocoder;

my $id;
my $address;

GetOptions(
    'id=s'      => \$id,
    'address=s' => \$address,
);

{
    if ($address) {
        get_lat_lng($address);
    }
    else {
        my $dbh = DBI->connect('dbi:mysql:tinma', 'root', undef,
            { AutoCommit => 1, RaiseError => 1 }
        );

        if ($id) {
            do_one($dbh, $id);
        }
        else {
            do_all($dbh);
        }

        $dbh->disconnect;
    }
}

sub do_one {
    my ($dbh, $id) = @_;

    my $shop = $dbh->selectrow_hashref(
        'SELECT * FROM shops WHERE id = ?',
        undef, $id
    );

    get_lat_lng($shop->{address});
}

sub do_all {
    my $dbh = shift;

    my $shops = $dbh->selectall_hashref('SELECT * FROM shops ORDER BY id ASC', 'id');

    foreach my $id (sort { $a <=> $b } keys %$shops) {
        my $shop = $shops->{$id};
        #print Dump $shop;
        get_lat_lng($shop->{address});
    }
}

my $geocoder;
sub get_lat_lng {
    my $address = shift;
	$geocoder ||= Geocoder->new;
    my ($lat, $lng) = $geocoder->get_lat_lng($address);
    print "$address: $lat, $lng\n";
    return ($lat, $lng);
}

__END__

