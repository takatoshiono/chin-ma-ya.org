#!/usr/bin/perl
use strict;
use warnings;
use WebService::Recruit::HotPepper;
use DBI;
use YAML;

MAIN:
{
    my $dbh = DBI->connect('dbi:mysql:tinma', 'root', undef,
        { AutoCommit => 1, RaiseError => 1 }
    );
    do_work($dbh);
    $dbh->disconnect();
}

sub do_work {
    my $dbh = shift;

    my $shops = fetch_shops($dbh);

    my $hp = WebService::Recruit::HotPepper->new(
        key       => 'guest',
        utf8_flag => 1,
    );

    SHOP:
    foreach my $shop (@$shops) {
        my $tinmas;
        eval {
            my $result = $hp->GourmetSearch(
                Keyword => sprintf('陳麻家 %s', $shop->{name}),
            );
            $tinmas = $result->root->Shop;
        };
        if ($@) {
            print STDERR "no shop found($shop->{name}): $@";
            next SHOP;
        }

        if (defined $tinmas and @$tinmas) {
            save_hotpepper($dbh, $shop->{id}, $tinmas->[0]);
        }
        else {
            print STDERR "0 shop found($shop->{name})\n";
        }
    }
}

sub fetch_shops {
    my $dbh = shift;
    my $shops = $dbh->selectall_arrayref(
        'SELECT * FROM shops WHERE deleted_at IS NULL ORDER BY id',
        { Slice => {} },
    );
    return $shops;
}

sub save_hotpepper {
    my ($dbh, $shop_id, $shop) = @_;

    print "save: $shop->{ShopName}\n";

    my ($is_exists) = $dbh->selectrow_array(q{
        SELECT 1 FROM hotpepper_shops
        WHERE shop_id_front = ? AND deleted_at IS NULL
    }, undef, $shop->{ShopIdFront});

    if ($is_exists) {
        update_hotpepper_shop($dbh, $shop);
    }
    else {
        insert_hotpepper_shop($dbh, $shop_id, $shop);
    }
}

sub update_hotpepper_shop {
    my ($dbh, $shop) = @_;

    my $sql = q{
        UPDATE hotpepper_shops
        SET
            shop_id_front = ?,
            shop_address = ?,
            shop_catch = ?,
            shop_name = ?,
            shop_name_kana = ?,
            shop_url = ?,
            access = ?,
            band = ?,
            barrier_free = ?,
            budget_average = ?,
            budget_cd = ?,
            budget_desc = ?,
            capacity = ?,
            card = ?,
            charter = ?,
            child = ?,
            close = ?,
            course = ?,
            english = ?,
            equipment = ?,
            food_cd = ?,
            food_name = ?,
            free_drink = ?,
            free_food = ?,
            genre_cd = ?,
            genre_catch = ?,
            genre_name = ?,
            horigotatsu = ?,
            karaoke = ?,
            ktai = ?,
            ktai_access = ?,
            ktai_coupon = ?,
            ktai_qr_url = ?,
            ktai_shop_url = ?,
            large_area_cd = ?,
            large_area_name = ?,
            large_service_area_cd = ?,
            large_service_area_name = ?,
            latitude = ?,
            longitude = ?,
            middle_area_cd = ?,
            middle_area_name = ?,
            non_smoking = ?,
            open = ?,
            open_air = ?,
            parking = ?,
            party_capacity = ?,
            pet = ?,
            mb_large_img = ?,
            mb_small_img = ?,
            pc_large_img = ?,
            pc_middle_img = ?,
            pc_small_img = ?,
            private_room = ?,
            service_area_cd = ?,
            service_area_name = ?,
            `show` = ?,
            small_area_cd = ?,
            small_area_name = ?,
            sommelier = ?,
            station_name = ?,
            tatami = ?,
            tv = ?,
            wedding = ?
        WHERE
            shop_id_front = ?
    };

    my @bind_values = (
        u2e($shop->{ShopIdFront}),
        u2e($shop->{ShopAddress}),
        u2e($shop->{ShopCatch}),
        u2e($shop->{ShopName}),
        u2e($shop->{ShopNameKana}),
        u2e($shop->{ShopUrl}),
        u2e($shop->{Access}),
        u2e($shop->{Band}),
        u2e($shop->{BarrierFree}),
        u2e($shop->{BudgetAverage}),
        u2e($shop->{BudgetCD}),
        u2e($shop->{udgetDesc}),
        u2e($shop->{Capacity}),
        u2e($shop->{Card}),
        u2e($shop->{Charter}),
        u2e($shop->{Child}),
        u2e($shop->{Close}),
        u2e($shop->{Course}),
        u2e($shop->{English}),
        u2e($shop->{Equipment}),
        u2e($shop->{FoodCD}),
        u2e($shop->{FoodName}),
        u2e($shop->{FreeDrink}),
        u2e($shop->{FreeFood}),
        u2e($shop->{GenreCD}),
        u2e($shop->{GenreCatch}),
        u2e($shop->{GenreName}),
        u2e($shop->{Horigotatsu}),
        u2e($shop->{Karaoke}),
        u2e($shop->{Ktai}),
        u2e($shop->{KtaiAccess}),
        u2e($shop->{KtaiCoupon}),
        u2e($shop->{KtaiQRUrl}),
        u2e($shop->{KtaiShopUrl}),
        u2e($shop->{LargeAreaCD}),
        u2e($shop->{LargeAreaName}),
        u2e($shop->{LargeServiceAreaCD}),
        u2e($shop->{LargeServiceAreaName}),
        u2e($shop->{Latitude}),
        u2e($shop->{Longitude}),
        u2e($shop->{MiddleAreaCD}),
        u2e($shop->{MiddleAreaName}),
        u2e($shop->{NonSmoking}),
        u2e($shop->{Open}),
        u2e($shop->{OpenAir}),
        u2e($shop->{Parking}),
        u2e($shop->{PartyCapacity}),
        u2e($shop->{Pet}),
        u2e($shop->{PictureUrl}{MbLargeImg}),
        u2e($shop->{PictureUrl}{MbSmallImg}),
        u2e($shop->{PictureUrl}{PcLargeImg}),
        u2e($shop->{PictureUrl}{PcMiddleImg}),
        u2e($shop->{PictureUrl}{PcSmallImg}),
        u2e($shop->{PrivateRoom}),
        u2e($shop->{ServiceAreaCD}),
        u2e($shop->{ServiceAreaName}),
        u2e($shop->{Show}),
        u2e($shop->{SmallAreaCD}),
        u2e($shop->{SmallAreaName}),
        u2e($shop->{Sommelier}),
        u2e($shop->{StationName}),
        u2e($shop->{Tatami}),
        u2e($shop->{Tv}),
        u2e($shop->{Wedding}),
        u2e($shop->{ShopIdFront}),
    );

    $dbh->do($sql, undef, @bind_values);
}

sub insert_hotpepper_shop {
    my ($dbh, $shop_id, $shop) = @_;

    my $sql = q{
        INSERT INTO hotpepper_shops(
            shop_id,
            shop_id_front,
            shop_address,
            shop_catch,
            shop_name,
            shop_name_kana,
            shop_url,
            access,
            band,
            barrier_free,
            budget_average,
            budget_cd,
            budget_desc,
            capacity,
            card,
            charter,
            child,
            close,
            course,
            english,
            equipment,
            food_cd,
            food_name,
            free_drink,
            free_food,
            genre_cd,
            genre_catch,
            genre_name,
            horigotatsu,
            karaoke,
            ktai,
            ktai_access,
            ktai_coupon,
            ktai_qr_url,
            ktai_shop_url,
            large_area_cd,
            large_area_name,
            large_service_area_cd,
            large_service_area_name,
            latitude,
            longitude,
            middle_area_cd,
            middle_area_name,
            non_smoking,
            open,
            open_air,
            parking,
            party_capacity,
            pet,
            mb_large_img,
            mb_small_img,
            pc_large_img,
            pc_middle_img,
            pc_small_img,
            private_room,
            service_area_cd,
            service_area_name,
            `show`,
            small_area_cd,
            small_area_name,
            sommelier,
            station_name,
            tatami,
            tv,
            wedding,
            created_at
        ) VALUES (
            ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,
            ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,
            ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,
            ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,
            ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,
            ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,
            ?, ?, ?, ?, ?, now()
        )
    };

    my @bind_values = (
        u2e($shop->{ShopIdFront}),
        u2e($shop->{ShopAddress}),
        u2e($shop->{ShopCatch}),
        u2e($shop->{ShopName}),
        u2e($shop->{ShopNameKana}),
        u2e($shop->{ShopUrl}),
        u2e($shop->{Access}),
        u2e($shop->{Band}),
        u2e($shop->{BarrierFree}),
        u2e($shop->{BudgetAverage}),
        u2e($shop->{BudgetCD}),
        u2e($shop->{BudgetDesc}),
        u2e($shop->{Capacity}),
        u2e($shop->{Card}),
        u2e($shop->{Charter}),
        u2e($shop->{Child}),
        u2e($shop->{Close}),
        u2e($shop->{Course}),
        u2e($shop->{English}),
        u2e($shop->{Equipment}),
        u2e($shop->{FoodCD}),
        u2e($shop->{FoodName}),
        u2e($shop->{FreeDrink}),
        u2e($shop->{FreeFood}),
        u2e($shop->{GenreCD}),
        u2e($shop->{GenreCatch}),
        u2e($shop->{GenreName}),
        u2e($shop->{Horigotatsu}),
        u2e($shop->{Karaoke}),
        u2e($shop->{Ktai}),
        u2e($shop->{KtaiAccess}),
        u2e($shop->{KtaiCoupon}),
        u2e($shop->{KtaiQRUrl}),
        u2e($shop->{KtaiShopUrl}),
        u2e($shop->{LargeAreaCD}),
        u2e($shop->{LargeAreaName}),
        u2e($shop->{LargeServiceAreaCD}),
        u2e($shop->{LargeServiceAreaName}),
        u2e($shop->{Latitude}),
        u2e($shop->{Longitude}),
        u2e($shop->{MiddleAreaCD}),
        u2e($shop->{MiddleAreaName}),
        u2e($shop->{NonSmoking}),
        u2e($shop->{Open}),
        u2e($shop->{OpenAir}),
        u2e($shop->{Parking}),
        u2e($shop->{PartyCapacity}),
        u2e($shop->{Pet}),
        u2e($shop->{PictureUrl}{MbLargeImg}),
        u2e($shop->{PictureUrl}{MbSmallImg}),
        u2e($shop->{PictureUrl}{PcLargeImg}),
        u2e($shop->{PictureUrl}{PcMiddleImg}),
        u2e($shop->{PictureUrl}{PcSmallImg}),
        u2e($shop->{PrivateRoom}),
        u2e($shop->{ServiceAreaCD}),
        u2e($shop->{ServiceAreaName}),
        u2e($shop->{Show}),
        u2e($shop->{SmallAreaCD}),
        u2e($shop->{SmallAreaName}),
        u2e($shop->{Sommelier}),
        u2e($shop->{StationName}),
        u2e($shop->{Tatami}),
        u2e($shop->{Tv}),
        u2e($shop->{Wedding}),
    );

    unshift @bind_values, $shop_id;

    $dbh->do($sql, undef, @bind_values);
}

# undefined to empty string
sub u2e {
    my $str = shift;
    if (defined $str) {
        return $str;
    }
    else {
        return '';
    }
}

__END__

