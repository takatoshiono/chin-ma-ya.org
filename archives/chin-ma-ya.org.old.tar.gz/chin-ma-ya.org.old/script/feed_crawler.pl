#!/usr/bin/perl
use strict;
use warnings;
use XML::RSS;
use LWP::UserAgent;
use YAML;
use DBI;

our $VERSION = '0.01';

{
    my $dbh = DBI->connect('dbi:mysql:tinma', 'root', undef,
        { AutoCommit => 1, RaiseError => 1 }
    );

    do_work($dbh);

    $dbh->disconnect;
}

sub do_work {
    my $dbh = shift;

    my $feeds = $dbh->selectall_arrayref(
        'SELECT * FROM feeds ORDER BY updated_at DESC',
        { Slice => {} },
    );

    #print Dump $feeds;

    my $ua = LWP::UserAgent->new();

    foreach my $feed (@$feeds) {
        my $url = $feed->{url};
        my $res = $ua->get($url);
        if ($res->is_success) {
            my $xml = $res->content;
            #print Dump $xml;
            my $rss = XML::RSS->new;
            $rss->parse($xml);
            #print Dump $rss->{items};
            foreach my $item (@{ $rss->{items} }) {
                save_feed_item($dbh, $feed->{id}, $item);
            }
        }
    }
}

# URLと日付でSELECTしてなかったらINSERTする
# 記事が更新された場合も新しいITEMとして扱うということ
sub save_feed_item {
    my ($dbh, $feed_id, $item) = @_;

    my $date_time;
    # 2007-09-07T00:21:18+09:00
    if ($item->{dc}{date} =~ /(\d{4}-\d{2}-\d{2})T(\d{2}:\d{2}:\d{2})/) {
        $date_time = "$1 $2";
    }
    else {
        print STDERR "invlid 'dc date': $item->{dc}{date}\n";
        return;
    }

    #print "$date_time\n";

    my $exists = $dbh->selectrow_hashref(
        'SELECT 1 FROM feed_items WHERE link = ? AND dc_date = ?',
        undef, $item->{link}, $date_time,
    );

    unless ($exists) {
        my $row = $dbh->do(
            q{
                INSERT INTO feed_items(
                    feed_id, title, link, dc_date, created_at
                ) VALUES (
                    ?, ?, ?, ?, now()
                )
            }, undef,
            $feed_id, $item->{title}, $item->{link}, $date_time
        );
        unless ($row) {
            print STDERR "failed to insert item: ", Dump $item;
        }
    }
}

__END__

