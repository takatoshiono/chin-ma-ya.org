#!/usr/bin/perl
use strict;
use warnings;
use DBI;
use Template;
use YAML;

{
    my $dbh = DBI->connect('dbi:mysql:tinma', 'root', undef,
        { AutoCommit => 1, RaiseError => 1 }
    );
    do_work($dbh);
    $dbh->disconnect;
}

sub do_work {
    my $dbh = shift;
    my $shops = fetch_shops($dbh);
    my $tt = Template->new()
        or die $Template::ERROR;;
    $tt->process(\*DATA, { shops => $shops }, 'mapplets.xml')
        or die $tt->error;
}

sub fetch_shops {
    my $dbh = shift;
    $dbh->selectall_arrayref(
        'SELECT * FROM shops ORDER BY id ASC',
        { Slice => {} }
    );
}

__END__
<?xml version="1.0" encoding="UTF-8"?>
<Module>
<ModulePrefs title="陳麻屋マップ" 
             description=""
             author="Takatoshi Ono"
             author_email="takatoshi.ono+mapplets@gmail.com"
             height="150">
  <Require feature="sharedmap"/>
</ModulePrefs>
<Content type="html"><![CDATA[

<dl>
[% FOREACH shop IN shops %]
<dt>[% shop.name %]</dt><dd>[% shop.extra %]</dd>
[% END %]
</dl>

<script>
  // Center the map in the Mediterranean and zoom out to a world view
  var map = new GMap2();
  var geoXml = new GGeoXml("http://takatoshi.dyndns.org/tinma/tinma.kml")

  map.setCenter(new GLatLng(35.646255, 139.713416), 5);
  map.addOverlay(geoXml);
</script>

]]></Content>
</Module>
