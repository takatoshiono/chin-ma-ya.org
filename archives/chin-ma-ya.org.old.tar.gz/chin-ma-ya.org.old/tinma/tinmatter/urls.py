from django.conf.urls.defaults import *

urlpatterns = patterns('tinma.tinmatter.views',
    url(r'^$', 'replies', name='tinmatter_replies')
)

