from django.shortcuts import render_to_response
from django.template import RequestContext
from django.views.decorators.cache import cache_page
import twitter

@cache_page(60)
def replies(request):
    import os
    os.putenv('USER', 'tinma') # for twitter._GetUsername()
    try:
        api = twitter.Api(username='tinma', password='tinmanko!1234')
        statuses = api.GetReplies()
    except:
        statuses = []

    return render_to_response(
        'tinmatter_replies.html',
        { 'statuses': statuses },
        context_instance=RequestContext(request)
    )

