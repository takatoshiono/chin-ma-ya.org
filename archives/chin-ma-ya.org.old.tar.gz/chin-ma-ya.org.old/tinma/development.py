# Django settings for tinma project(development).

from settings import *

DEBUG = True
TEMPLATE_DEBUG = DEBUG

DATABASE_ENGINE = 'mysql'           # 'postgresql_psycopg2', 'postgresql', 'mysql', 'sqlite3' or 'ado_mssql'.
DATABASE_NAME = 'tinma_dev'             # Or path to database file if using sqlite3.
DATABASE_USER = 'root'             # Not used with sqlite3.
DATABASE_PASSWORD = ''         # Not used with sqlite3.
DATABASE_HOST = ''             # Set to empty string for localhost. Not used with sqlite3.
DATABASE_PORT = ''             # Set to empty string for default. Not used with sqlite3.

MEDIA_ROOT = '/Users/takatoshi/repos/chin-ma-ya.org/htdocs/media/'
#MEDIA_URL = 'http://localhost:8000/media/'
MEDIA_URL = '/media/'
TEMPLATE_DIRS = (
    '/Users/takatoshi/repos/chin-ma-ya.org/tinma/templates',
)

DEFAULT_FROM_EMAIL = 'info@chin-ma-ya.org'

