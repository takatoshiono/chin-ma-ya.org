# -*- encoding: utf-8 -*-
from django.contrib.syndication.feeds import Feed
from tinma.shops.models import Shop
from tinma.memo.models import Memo

class UpdatedShops(Feed):
    title = "陳麻家マップ 最新店舗情報"
    link  = "/shops/"
    description = "陳麻家の店舗更新情報をお届けします"

    def items(self):
        return Shop.objects.order_by('-updated_at')[:5]

class UpdatedMemos(Feed):
    title = "陳麻家メモ"
    link = "/memo/"
    description = "陳麻家メモの新着情報をお届けします"

    def items(self):
        return Memo.objects.order_by('-updated_at')[:10]

