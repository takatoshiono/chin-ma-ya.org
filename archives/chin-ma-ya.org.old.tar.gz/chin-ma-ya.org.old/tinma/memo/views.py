from django.shortcuts import render_to_response, get_object_or_404
from django.template import RequestContext
from django import newforms as forms
from django.contrib.auth.decorators import login_required
from django.http import HttpResponseRedirect
from django.core.urlresolvers import reverse
from tinma.memo.models import Memo, Photo
from tinma.shops.models import Shop

class PhotoForm(forms.Form):
    image1 = forms.ImageField(required=False)
    image2 = forms.ImageField(required=False)
    image3 = forms.ImageField(required=False)

class PhotoEditForm(forms.Form):
    image1 = forms.ImageField(required=False)
    image2 = forms.ImageField(required=False)
    image3 = forms.ImageField(required=False)
    delete1 = forms.BooleanField(required=False, initial=False)
    delete2 = forms.BooleanField(required=False, initial=False)
    delete3 = forms.BooleanField(required=False, initial=False)

class MemoForm(forms.Form):
    shop = forms.ModelChoiceField(queryset=Shop.objects.all())
    title = forms.CharField(max_length=30)
    memo = forms.CharField(widget=forms.Textarea)

@login_required
def create(request):
    if request.POST:
        memo_form = MemoForm(request.POST)
        photo_form = PhotoForm(request.POST, request.FILES)

        if memo_form.is_valid() and photo_form.is_valid():
            data = memo_form.cleaned_data
            m = Memo(shop_id=data['shop'].id, user=request.user, title=data['title'], memo=data['memo'])
            m.save()

            for key in request.FILES.keys():
                image = request.FILES[key]
                if image != None:
                    p = Photo(memo=m, image=image['filename'])
                    p.save_image_file(image['filename'], image['content'])
                else:
                    break

            return HttpResponseRedirect(reverse('memo_index'))
    else:
        memo_form = MemoForm()
        photo_form = PhotoForm()

    return render_to_response(
        'create_form.html',
        {'memo_form': memo_form, 'photo_form': photo_form},
        context_instance=RequestContext(request)
    )

@login_required
def edit(request, memo_id):
    memo = get_object_or_404(Memo, id=memo_id)

    if request.user.id != memo.user.id:
        return HttpResponseRedirect(reverse('memo_index'))

    photos = memo.photo_set.all()

    if request.POST:
        memo_form = MemoForm(request.POST)
        photo_form = PhotoEditForm(request.POST, request.FILES)

        if memo_form.is_valid() and photo_form.is_valid():
            memo_data = memo_form.cleaned_data
            photo_data = photo_form.cleaned_data

            memo.shop = memo_data['shop']
            memo.title = memo_data['title']
            memo.memo = memo_data['memo']
            memo.save()

            for i in range(3):
                key = 'delete%d' % (i + 1)
                if photo_data[key]:
                    photos[i].delete()

            for key in request.FILES.keys():
                image = request.FILES[key]
                if image != None:
                    p = Photo(memo=memo, image=image['filename'])
                    p.save_image_file(image['filename'], image['content'])
                else:
                    break

            return HttpResponseRedirect(reverse('memo_index'))
    else:
        memo_form = MemoForm({
            'shop': memo.shop.id,
            'title': memo.title,
            'memo': memo.memo,
        })
        photo_form = PhotoEditForm()


    dictionary = {'memo_form': memo_form, 'photo_form': photo_form}
    counter = 1
    for photo in photos:
        key = 'photo%d' % (counter)
        dictionary[key] = photo
        counter += 1

    return render_to_response(
        'edit_form.html',
        dictionary,
        context_instance=RequestContext(request)
    )

@login_required
def delete(request):
    if request.POST:
        memo_id = request.POST['memo_id']
        memo = get_object_or_404(Memo, id=memo_id)

        if request.user.id == memo.user.id:
            memo.delete()

    return HttpResponseRedirect(reverse('memo_index'))

