from django.conf.urls.defaults import *
from tinma.memo.models import Memo, Photo

info_dict = {
    'queryset': Memo.objects.all().order_by('-updated_at')
}

urlpatterns = patterns('django.views.generic',
    url(r'^$', 'list_detail.object_list',
     dict(info_dict, template_name='list.html'), 'memo_index'),
    url(r'^(?P<object_id>\d+)/$', 'list_detail.object_detail',
     dict(info_dict, template_name='detail.html'), 'memo_detail'),
)

urlpatterns += patterns('tinma.memo.views',
    url(r'^create/$', 'create', name='memo_create'),
    url(r'^edit/(?P<memo_id>\d+)/$', 'edit', name='memo_edit'),
    url(r'^delete/$', 'delete', name='memo_delete'),
)

