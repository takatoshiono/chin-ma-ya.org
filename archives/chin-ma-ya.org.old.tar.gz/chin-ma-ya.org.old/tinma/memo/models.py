# -*- encoding: utf-8 -*-
from django.db import models
from django.db.models import permalink
from django.contrib.auth.models import User
from django.conf import settings
from tinma.shops.models import Shop
from datetime import datetime
from PIL import Image
import os
import time

class Memo(models.Model):
    """Memos about tinma"""
    user = models.ForeignKey(User)
    shop = models.ForeignKey(Shop)
    title = models.CharField(max_length=30)
    memo = models.TextField()
    updated_at = models.DateTimeField('更新日時', auto_now=True)
    created_at = models.DateTimeField('作成日時', auto_now_add=True)

    def __unicode__(self):
        return "%s" % (self.title, )

    @permalink
    def get_absolute_url(self):
        return ('memo_detail', [str(self.id)])

    class Admin:
        pass

class Photo(models.Model):
    """Photos about tinma"""
    memo = models.ForeignKey(Memo, edit_inline=models.TABULAR)
    image = models.ImageField(upload_to="photos/%Y/%m/%d")
    thumb = models.ImageField(upload_to="photos/%Y/%m/%d", blank=True)
    delete_flag = models.BooleanField("削除する", default=False, core=True)
    updated_at = models.DateTimeField(auto_now=True)
    created_at = models.DateTimeField(default=datetime.now(), editable=False)

    def save(self):
        if self.delete_flag:
            if self.id:
                super(Photo, self).delete()
            return

        if not self.id and not self.image:
            return

        if not os.path.exists(self.get_thumb_filename()):
            try:
                infile = self.get_image_filename()
                im = Image.open(infile)
                im.thumbnail(settings.THUMBNAIL_IMAGE_SIZE, Image.ANTIALIAS)
                root, ext = os.path.splitext(os.path.basename(infile))
                self.thumb = os.path.join(time.strftime("photos/%Y/%m/%d"), "%s.thumb%s" % (root, ext))
                im.save(self.get_thumb_filename())
            except IOError:
                raise

        super(Photo, self).save()

    def __unicode__(self):
        return "%s" % (self.image)

