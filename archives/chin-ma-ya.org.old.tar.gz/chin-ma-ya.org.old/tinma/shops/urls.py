from django.conf.urls.defaults import *
from tinma.shops.models import Shop, HotPepperShop

info_dict = {
    'queryset': Shop.objects.all()
}

urlpatterns = patterns('',
    url(r'^$',
     'django.views.generic.list_detail.object_list',
     dict(info_dict, paginate_by=50, template_name='shop_list.html'),
     'shop_list'),

    url(r'^(?P<object_id>\d+)/$',
     'django.views.generic.list_detail.object_detail',
     dict(info_dict, template_name='shop_detail.html'),
     'shop_detail'),

    url(r'^kml/$',
     'django.views.generic.list_detail.object_list',
     dict(info_dict, mimetype='text/plain', template_name='shop_list.kml'),
     'shop_kml'),

    url(r'^kml/earth/$',
     'django.views.generic.list_detail.object_list',
     dict(info_dict, mimetype='application/vnd.google-earth.kml+xml', template_name='shop_list.kml'),
     'shop_kml_earth'),
)

