# -*- encoding: utf-8 -*-
from django.db import models
from django.db.models import permalink
import datetime

class AreaManager(models.Manager):
    def get_query_set(self):
        return super(AreaManager, self).get_query_set().filter(
            deleted_at__isnull=True
        )

class Area(models.Model):
    name = models.CharField('地域名', max_length=16)
    initial_words = models.CharField('頭文字', max_length=3)
    url = models.URLField(help_text='陳麻家の店舗ページURLを指定します')
    updated_at = models.DateTimeField('更新日時', auto_now=True)
    created_at = models.DateTimeField('作成日時', auto_now_add=True)
    deleted_at = models.DateTimeField('削除日時', null=True, blank=True)

    objects = AreaManager()

    def __unicode__(self):
        return self.name

    def delete(self):
        self.deleted_at = datetime.datetime.now()
        self.save()

    class Meta:
        db_table = 'areas'
        verbose_name = '地域'
        verbose_name_plural = '地域'
        permissions = (
            ('can_view', 'Can view area'),
        )

    class Admin:
        fields = (
            (None, {
                'fields': ('name', 'initial_words', 'url'),
            }),
        )
        list_display = ('id', 'name', 'updated_at', 'created_at')
        list_display_links = ('name',)
        ordering = ['id']

class ShopManager(models.Manager):
    def get_query_set(self):
        return super(ShopManager, self).get_query_set().filter(
            deleted_at__isnull=True,
            area__deleted_at__isnull=True
        )

class Shop(models.Model):
    area = models.ForeignKey(Area, verbose_name='地域')
    name = models.CharField('店舗名', max_length=32, unique=True)
    address = models.CharField('住所', max_length=200)
    latitude = models.CharField('緯度', max_length=16)
    longitude = models.CharField('経度', max_length=16)
    extra = models.CharField('追加情報', max_length=400)
    updated_at = models.DateTimeField('更新日時', auto_now=True)
    created_at = models.DateTimeField('作成日時', auto_now_add=True)
    deleted_at = models.DateTimeField('削除日時', null=True, blank=True)

    objects = ShopManager()

    def __unicode__(self):
        return self.name

    def delete(self):
        self.deleted_at = datetime.datetime.now()
        self.save()

    @permalink
    def get_absolute_url(self):
        return ('shop_detail', [str(self.id)])

    class Meta:
        db_table = 'shops'
        verbose_name = '店舗'
        verbose_name_plural = '店舗'

    class Admin:
        fields = (
            (None, {
                'fields': ('area', 'name', 'address', 'latitude', 'longitude', 'extra'),
            }),
        )
        list_display = ('id', 'name', 'updated_at', 'created_at')
        list_display_links = ('name',)
        ordering = ['-updated_at', '-id']

        manager = ShopManager()

class GnaviShopManager(models.Manager):
    def get_query_set(self):
        return super(GnaviShopManager, self).get_query_set().filter(
            deleted_at__isnull=True,
            shop__deleted_at__isnull=True
        )

class GnaviShop(models.Model):
    shop           = models.ForeignKey(Shop)
    gnavi_shop_id  = models.CharField(max_length=8, unique=True)
    name           = models.CharField(max_length=16)
    name_kana      = models.CharField(max_length=32)
    url            = models.CharField(max_length=200)
    url_mobile     = models.CharField(max_length=200)
    shop_image1    = models.CharField(max_length=200)
    shop_image2    = models.CharField(max_length=200)
    qrcode         = models.CharField(max_length=200)
    address        = models.CharField(max_length=200)
    tel            = models.CharField(max_length=16)
    fax            = models.CharField(max_length=16)
    opentime       = models.CharField(max_length=16)
    holiday        = models.CharField(max_length=16)
    line           = models.CharField(max_length=16)
    station        = models.CharField(max_length=16)
    station_exit   = models.CharField(max_length=16)
    walk           = models.CharField(max_length=16)
    note           = models.CharField(max_length=100)
    pr_short       = models.CharField(max_length=50)
    pr_long        = models.CharField(max_length=200)
    budget         = models.CharField(max_length=100)
    equipment      = models.CharField(max_length=100)
    updated_at     = models.DateTimeField(auto_now=True)
    created_at     = models.DateTimeField(auto_now_add=True)
    deleted_at     = models.DateTimeField(null=True, blank=True)

    objects = GnaviShopManager()

    def __unicode(self):
        return self.name

    def delete(self):
        self.deleted_at = datetime.datetime.now()
        self.save()

    class Meta:
        db_table = 'gnavi_shops'
        verbose_name = 'ぐるなび店舗情報'
        verbose_name_plural = 'ぐるなび店舗情報'

    class Admin:
        list_display = ('id', 'gnavi_shop_id', 'name', 'updated_at', 'created_at')
        list_display_links = ('name',)
        ordering = ['-updated_at', '-id']

        manager = GnaviShopManager()

class HotPepperShopManager(models.Manager):
    def get_query_set(self):
        return super(HotPepperShopManager, self).get_query_set().filter(
            deleted_at__isnull=True,
            shop__deleted_at__isnull=True
        )

class HotPepperShop(models.Model):
    shop                    = models.ForeignKey(Shop)
    shop_id_front           = models.CharField(max_length=16)
    shop_address            = models.CharField(max_length=200)
    shop_catch              = models.CharField(max_length=100)
    shop_name               = models.CharField(max_length=32)
    shop_name_kana          = models.CharField(max_length=64)
    shop_url                = models.CharField(max_length=200)
    access                  = models.CharField(max_length=32)
    band                    = models.CharField(max_length=8)
    barrier_free            = models.CharField(max_length=8)
    budget_average          = models.CharField(max_length=8)
    budget_cd               = models.CharField(max_length=8)
    budget_desc             = models.CharField(max_length=8)
    capacity                = models.CharField(max_length=8)
    card                    = models.CharField(max_length=8)
    charter                 = models.CharField(max_length=8)
    child                   = models.CharField(max_length=16)
    close                   = models.CharField(max_length=32)
    course                  = models.CharField(max_length=8)
    english                 = models.CharField(max_length=8)
    equipment               = models.CharField(max_length=8)
    food_cd                 = models.CharField(max_length=8)
    food_name               = models.CharField(max_length=16)
    free_drink              = models.CharField(max_length=8)
    free_food               = models.CharField(max_length=8)
    genre_cd                = models.CharField(max_length=8)
    genre_catch             = models.CharField(max_length=16)
    genre_name              = models.CharField(max_length=16)
    horigotatsu             = models.CharField(max_length=8)
    karaoke                 = models.CharField(max_length=16)
    ktai                    = models.CharField(max_length=16)
    ktai_access             = models.CharField(max_length=64)
    ktai_coupon             = models.IntegerField()
    ktai_qr_url             = models.CharField(max_length=200)
    ktai_shop_url           = models.CharField(max_length=200)
    large_area_cd           = models.CharField(max_length=8)
    large_area_name         = models.CharField(max_length=8)
    large_service_area_cd   = models.CharField(max_length=8)
    large_service_area_name = models.CharField(max_length=8)
    latitude                = models.CharField(max_length=16)
    longitude               = models.CharField(max_length=16)
    middle_area_cd          = models.CharField(max_length=8)
    middle_area_name        = models.CharField(max_length=32)
    non_smoking             = models.CharField(max_length=8)
    open                    = models.CharField(max_length=100)
    open_air                = models.CharField(max_length=8)
    parking                 = models.CharField(max_length=8)
    party_capacity          = models.CharField(max_length=8)
    pet                     = models.CharField(max_length=8)
    mb_large_img            = models.CharField(max_length=200)
    mb_small_img            = models.CharField(max_length=200)
    pc_large_img            = models.CharField(max_length=200)
    pc_middle_img           = models.CharField(max_length=200)
    pc_small_img            = models.CharField(max_length=200)
    private_room            = models.CharField(max_length=8)
    service_area_cd         = models.CharField(max_length=8)
    service_area_name       = models.CharField(max_length=8)
    show                    = models.CharField(max_length=8)
    small_area_cd           = models.CharField(max_length=8)
    small_area_name         = models.CharField(max_length=16)
    sommelier               = models.CharField(max_length=8)
    station_name            = models.CharField(max_length=8)
    tatami                  = models.CharField(max_length=8)
    tv                      = models.CharField(max_length=8)
    wedding                 = models.CharField(max_length=8)
    updated_at              = models.DateTimeField(auto_now=True)
    created_at              = models.DateTimeField(auto_now_add=True)
    deleted_at              = models.DateTimeField(null=True, blank=True)

    objects = HotPepperShopManager()

    def __unicode(self):
        return self.name

    def delete(self):
        self.deleted_at = datetime.datetime.now()
        self.save()

    class Meta:
        db_table = 'hotpepper_shops'
        verbose_name = 'ホットペッパー店舗情報'
        verbose_name_plural = 'ホットペッパー店舗情報'

    class Admin:
        list_display = ('id', 'shop_id_front', 'shop_name', 'updated_at', 'created_at')
        list_display_links = ('shop_name',)
        ordering = ['-updated_at', '-id']

        manager = HotPepperShopManager()

