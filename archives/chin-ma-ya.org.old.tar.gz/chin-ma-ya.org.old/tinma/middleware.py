from uamobile import detect, exceptions
from django.conf import settings
from django.db import connection

class UserAgentMobileMiddleware(object):
    def process_request(self, request):
        try:
            request.device = detect(request.META)
        except exceptions.NoMatchingError, e:
            # continue processing as non-mobile
            request.device = detect({})

class DBDebugMiddleware:
    def process_response(self, request, response):
        if settings.DEBUG:
            for query in connection.queries:
                print "cost: %s \n sql: %s" % (query['time'], query['sql'])
        return response

