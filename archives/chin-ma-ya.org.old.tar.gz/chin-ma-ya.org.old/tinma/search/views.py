# Create your views here.
from django.shortcuts import render_to_response
from django.template import RequestContext
from django import newforms as forms

def index(request):
    #template = '%s/search_form.html' % request.device.short_carrier
    template = 'search_form.html'
    return render_to_response(
        template,
        {},
        context_instance=RequestContext(request)
    )

