from django.conf.urls.defaults import *

urlpatterns = patterns('tinma.search.views',
    url(r'^$', 'index', name='search_index'),
)

