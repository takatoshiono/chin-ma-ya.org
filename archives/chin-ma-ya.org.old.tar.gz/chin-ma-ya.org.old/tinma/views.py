from django.shortcuts import render_to_response, get_object_or_404
from django.template import RequestContext
from django.http import HttpResponseRedirect
from django.core.urlresolvers import reverse
from django import newforms as forms
from django.contrib.auth.models import User
from django.contrib.auth.decorators import login_required

def index(request):
    template = '%s/index.html' % request.device.short_carrier
    return render_to_response(
        template,
        { 'lat': request.GET.get('lat', 0),
          'lng': request.GET.get('lng', 0) },
        context_instance=RequestContext(request)
    )

@login_required
def profile(request):
    template = '%s/profile.html' % request.device.short_carrier
    return render_to_response(
        template,
        {},
        context_instance=RequestContext(request)
    )

class EmailChangeForm(forms.Form):
    email = forms.EmailField(required=True)

@login_required
def email_change(request):
    user = get_object_or_404(User, id=request.user.id)

    if request.POST:
        form = EmailChangeForm(request.POST)
        if form.is_valid():
            data = form.cleaned_data
            user.email = data['email']
            user.save()

            return HttpResponseRedirect(reverse('email_change_done'))

    else:
        form = EmailChangeForm({'email': user.email})

    return render_to_response(
        'N/email_change_form.html',
        {'form': form},
        context_instance=RequestContext(request)
    )

@login_required
def email_change_done(request):
    return render_to_response(
        'N/email_change_done.html',
        {},
        context_instance=RequestContext(request)
    )

