from django.conf.urls.defaults import *
from django.conf import settings
from tinma.feeds import UpdatedShops, UpdatedMemos

feeds = {
    'shop': UpdatedShops,
    'memo': UpdatedMemos,
}

# tinma
urlpatterns = patterns('tinma.views',
    url(r'^$', 'index', name='index'),
    url(r'^accounts/profile/$', 'profile', name='profile'),
    url(r'^accounts/email_change/$', 'email_change', name='email_change'),
    url(r'^accounts/email_change/done/$', 'email_change_done', name='email_change_done'),
)

# generic
urlpatterns += patterns('django.views.generic',
    url(r'^tos/$', 'simple.direct_to_template',
     {'template': 'tos.html'}, name='tos'),
    url(r'^privacypolicy/$', 'simple.direct_to_template',
     {'template': 'privacypolicy.html'}, name='privacypolicy'),
    url(r'^map/$', 'simple.direct_to_template',
     {'template': 'map_full.html'}, name='map_full'),
)

# accounts
urlpatterns += patterns('django.contrib.auth.views',
    url(r'^accounts/password_change/$', 'password_change',
     {'template_name': 'registration/password_change_form.html'}, name='password_change'),
    url(r'^accounts/password_change/done/$', 'password_change_done',
     {'template_name': 'registration/password_change_done.html'}, name='password_change'),
)

# registration.views
urlpatterns += patterns('registration.views',
    url(r'^accounts/register/$', 'register',
     { 'success_url': '/accounts/register/complete/' }, name='registration_register'),
)

# include
urlpatterns += patterns('',
    (r'^tinmatter/', include('tinma.tinmatter.urls')),
    (r'^shops/', include('tinma.shops.urls')),
    (r'^memo/', include('tinma.memo.urls')),
    (r'^search/', include('tinma.search.urls')),
    (r'^admin/', include('django.contrib.admin.urls')),
    (r'^accounts/', include('registration.urls')),
    (r'^openid/', include('tinma.openid_consumer.urls')),
)

# feed
urlpatterns += patterns('django.contrib.syndication.views',
    (r'^feeds/(?P<url>.+)/$', 'feed', {'feed_dict': feeds}),
)

# debug
if settings.DEBUG:
    urlpatterns += patterns('',
        (r'media/(?P<path>.*)$', 'django.views.static.serve',
         { 'document_root': '/Users/takatoshi/repos/chin-ma-ya.org/htdocs/media' }),
    )

