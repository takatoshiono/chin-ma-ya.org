from django.db import models
from django.contrib.auth.models import User

class OpenIdUser(models.Model):
    """Openid User"""
    user = models.ForeignKey(User)
    openid_url = models.CharField(max_length=255, unique=True)
    updated_at = models.DateTimeField(auto_now=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __unicode__(self):
        return "%s" % (self.openid_url)

    class Admin:
        pass

