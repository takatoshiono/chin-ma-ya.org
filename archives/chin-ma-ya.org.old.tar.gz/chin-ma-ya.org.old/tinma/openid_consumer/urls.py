
from django.conf.urls.defaults import *

urlpatterns = patterns('tinma.openid_consumer.views',
    url(r'^$', 'startOpenID', name='openid_start'),
    url(r'^finish/$', 'finishOpenID', name='openid_finish'),
    url(r'^xrds/$', 'rpXRDS', name='openid_xrds'),
    url(r'^edit_username/$', 'edit_username', name='openid_edit_username'),
)
