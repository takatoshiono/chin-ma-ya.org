drop table if exists feed_items;
drop table if exists feeds;

create table feeds (
    id int unsigned not null auto_increment,
    url text not null,
    updated_at timestamp,
    created_at datetime,
    primary key (id)
);

create table feed_items (
    id int unsigned not null auto_increment,
    feed_id int unsigned not null,
    title text not null,
    link text not null,
    dc_date datetime not null,
    updated_at timestamp,
    created_at datetime,
    primary key (id),
    INDEX idx_dc_date (dc_date),
    constraint foreign key (feed_id) references feeds (id)
);

