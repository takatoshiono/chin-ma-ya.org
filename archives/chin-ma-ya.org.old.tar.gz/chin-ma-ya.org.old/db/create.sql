create table areas (
    id int not null auto_increment,
    name varchar(16) not null,
    initial_words varchar(3) not null,
    url text not null,
    updated_at timestamp not null,
    created_at datetime not null,
    deleted_at datetime,
    primary key (id)
) engine=innodb default charset=utf8;

create table shops (
    id int not null auto_increment,
    area_id int not null,
    name varchar(32) not null,
    address text not null,
    latitude varchar(16),
    longitude varchar(16),
    extra text,
    updated_at timestamp not null,
    created_at datetime not null,
    deleted_at datetime,
    primary key (id),
    index idx_area_id (area_id),
    unique index idx_name (name),
    constraint foreign key (area_id) references areas (id)
) engine=innodb default charset=utf8;

