insert into areas(name, initial_words, url, created_at) values('北海道・東北', 'ht', 'http://www.chin-ma-ya.com/tenpo/ht.html', now());
insert into areas(name, initial_words, url, created_at) values('関東', 'k', 'http://www.chin-ma-ya.com/tenpo/k.html', now());
insert into areas(name, initial_words, url, created_at) values('甲信越・北陸', 'kh', 'http://www.chin-ma-ya.com/tenpo/kh.html', now());
insert into areas(name, initial_words, url, created_at) values('東海・近畿', 'tk', 'http://www.chin-ma-ya.com/tenpo/tk.html', now());
insert into areas(name, initial_words, url, created_at) values('中国', 'chu', 'http://www.chin-ma-ya.com/tenpo/chu.html', now());
insert into areas(name, initial_words, url, created_at) values('九州・沖縄', 'ko', 'http://www.chin-ma-ya.com/tenpo/ko.html', now());
